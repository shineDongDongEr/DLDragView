//
//  ViewController.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/6.
//

import UIKit

class ViewController: UIViewController{
    let cellId = "cellId"
    @IBOutlet weak var tableView: UITableView!
    
    lazy var titleArray: [String] = {
        return ["普通展示弹框", "两层可滑动弹框", "三层可滑动弹框", "弹框内部可垂直滑动处理", "弹框内部可左右，垂直滑动处理"]
    }()
        
    // MARK: - lifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "主页面"
        configTableView()
    }
    
    // MARK: - privateMethod
    func configTableView(){
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "AKDragTestCell", bundle: nil), forCellReuseIdentifier: cellId)
    }
}

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as? AKDragTestCell{
            cell.text = titleArray[indexPath.row]
            return cell
        }
        return UITableViewCell()
    }
}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
//            let oneVc = ShowOneViewController()
//            self.navigationController?.pushViewController(oneVc, animated: true)
            let oneVc = ShowOneViewController()
            navigationController?.pushViewController(oneVc, animated: true)
        }else if indexPath.row == 1{
            let twoVc = ShowTwoViewController()
            self.navigationController?.pushViewController(twoVc, animated: true)
        }else if indexPath.row == 2{
            let thirdCommonVc = ShowThirdCommonViewController()
            self.navigationController?.pushViewController(thirdCommonVc, animated: true)
        }else if indexPath.row == 3{
            let thirdTabVc = ShowThirdTabViewController()
            self.navigationController?.pushViewController(thirdTabVc, animated: true)
        }else if indexPath.row == 4{
            let thirdTabVc = ShowFourViewController()
            self.navigationController?.pushViewController(thirdTabVc, animated: true)
        }
        
    }
}

