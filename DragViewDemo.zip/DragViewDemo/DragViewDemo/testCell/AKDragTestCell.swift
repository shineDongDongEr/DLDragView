//
//  AKDragTestCell.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class AKDragTestCell: UITableViewCell {

    @IBOutlet weak var title: UILabel!
    var text: String = ""{
        didSet{
            title.text = text
        }
    }
    var textColor: UIColor?{
        didSet{
            title.textColor = textColor
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
