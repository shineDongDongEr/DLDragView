//
//  ThirdLayersViewController.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class customStyleModel: NSObject{
    var customText: String = ""
    var customColor: UIColor = .yellow
    init(customText: String, customColor: UIColor) {
        self.customText = customText
        self.customColor = customColor
    }
}

class ThirdLayersViewController: UIViewController {
    let testCellId = "testCellId"
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var customTitle: UILabel!
    @IBOutlet weak var titleBgView: UIView!
    
    var customModel: customStyleModel?
    
    convenience init(_ customModel: customStyleModel) {
        self.init(nibName: nil, bundle: nil)
        self.customModel = customModel
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let model = customModel{
            customTitle.text = model.customText
            titleBgView.backgroundColor = model.customColor
        }
        tableView.dataSource = self
        tableView.bounces = false
        tableView.register(UINib(nibName: "AKDragTestCell", bundle: nil), forCellReuseIdentifier: testCellId)
    }
}

extension ThirdLayersViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        28
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: testCellId, for: indexPath) as? AKDragTestCell{
            cell.text = "我是测试的第\(indexPath.row)行"
            cell.title.textColor = .systemPink
            return cell
        }
        return UITableViewCell()
    }
}
