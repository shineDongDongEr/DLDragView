//
//  FourLayersViewController.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit
enum VcStyle: String {
    case left, middle, right
}
class FourLayersViewController: UITableViewController {
    let testCellId = "testCellId"
    var style: VcStyle = .middle
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UINib(nibName: "AKDragTestCell", bundle: nil), forCellReuseIdentifier: testCellId)
    }
    
    convenience init(_ style: VcStyle) {
        self.init(nibName: nil, bundle: nil)
        self.style = style
    }

    // MARK: - Table view data source


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 38
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: testCellId, for: indexPath) as? AKDragTestCell{
            if style == .left{
                cell.text = "我是左页的第\(indexPath.row)行"
                cell.title.textColor = .systemRed
            }else if style == .middle{
                cell.text = "我是中间页的第\(indexPath.row)行"
                cell.title.textColor = .systemGreen
            }else if style == .right{
                cell.text = "我是右页的第\(indexPath.row)行"
                cell.title.textColor = .systemYellow
            }
            return cell
        }
        return UITableViewCell()
    }
}
