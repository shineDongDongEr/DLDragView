//
//  AKOneDragView.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class AKOneDragView: DraggableBoxView {
    lazy var oneView: UIView = {
        let oneView = UIView()
        oneView.backgroundColor = .orange
        return oneView
    }()

    override var minHeight: CGFloat? {
        return 0
    }
    
    override var maxHeight: CGFloat {
        return 300
    }
    
    override var dimmingColor: UIColor {
        return .clear
    }
    
    override var canDrag: Bool{
        return false
    }
    
    open override var animateWhenFirstAppear: Bool {
        
        return true
    }
    
    override func createContentView(_ boxView: UIView) -> UIView {
        
        return oneView
    }
  
}
