//
//  AKFourDragView.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class AKFourDragView: DraggableBoxView {

    lazy var fourVc: HomeMainViewController = {
        let fourVc = HomeMainViewController()
        return fourVc
    }()

    override var minHeight: CGFloat? {
        
        return 80
    }
    
    override var middleHeight: CGFloat? {
        
        return 305
    }
            
    override var maxHeight: CGFloat {
        
        return UIScreen.main.bounds.size.height - 88
    }
    
    override var dimmingColor: UIColor {
        return .clear
    }
    
    open override var animateWhenFirstAppear: Bool {
        
        return false
    }
    
    override func createContentView(_ boxView: UIView) -> UIView {
        
        return fourVc.view
    }
    
    override var verticalScrollViews: [UIScrollView]?{
        return [fourVc.leftVc.tableView, fourVc.middleVc.tableView, fourVc.rightVc.tableView]
    }
    
    override var topHeadDragHeight: CGFloat?{
        return 56
    }
    
    override var dragStatus: DraggableBoxView.DragStatus{
        didSet{
            self.fourVc.makeSwipGesture(dragStatus == .top)
        }
    }
    
    //这里单独处理头部无法下拉问题
    override func bounceBackToNearestLocation(_ velocityY: CGFloat) {
        //这里56为自定义头部的searchView的高度，当手势从最顶部下拉时
        if startPanY < topHeadDragHeight ?? 56 && (dragStatus == .top) {
            // 手势在顶部操作的代码
            isTopToPullDown = true
            // 确保 scrollView 在主线程上进行操作
            DispatchQueue.main.async {
                self.currentVerticalScrollView?.setContentOffset(.zero, animated: false)
            }
        } else {
            // 手势在中间或底部操作的代码
            isTopToPullDown = false
        }

        let offsetYDelta = self.boxTopConstraint.constant - initialOffsetY
        if offsetYDelta == 0 && dragStatus == .middle{
            isFirstMiddeleUp = true
        }else{
            isFirstMiddeleUp = false
        }
        super.bounceBackToNearestLocation(velocityY)
    }
    
    //是否要等冲突手势失败后，才响应自己的手势，返回true，要等，返回false不等，直接处理自己手势逻辑
    override func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRequireFailureOf otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        let scrolls = self.fourVc.getAllScrolls()
        let contains = scrolls.compactMap({$0.panGestureRecognizer}).contains(otherGestureRecognizer)
        if contains == true {
            return true  //先处理自己
        }
        return false   //同时处理自己and其他手势
    }

}
