//
//  AKTwoDragView.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class AKTwoDragView: DraggableBoxView {
    lazy var oneView: UIView = {
        let oneView = UIView()
        oneView.backgroundColor = .systemPink
        return oneView
    }()

    override var minHeight: CGFloat? {
        return 100
    }
    
    override var maxHeight: CGFloat {
        return 500
    }
    
    override var dimmingColor: UIColor {
        return .clear
    }
    open override var animateWhenFirstAppear: Bool {
        
        return true
    }
    
    override func createContentView(_ boxView: UIView) -> UIView {
        
        return oneView
    }
  

}
