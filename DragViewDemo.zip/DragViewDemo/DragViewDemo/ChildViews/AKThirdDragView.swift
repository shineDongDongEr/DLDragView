//
//  AKThirdDragView.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class AKThirdDragView: DraggableBoxView {
    
    lazy var thirdVc: ThirdLayersViewController = {
        let thirdVc = ThirdLayersViewController()
        return thirdVc
    }()

    override var minHeight: CGFloat? {
        
        return 80
    }
    
    override var topCornerRadius: CGFloat{
        
        return 0
    }
    
    override var middleHeight: CGFloat? {
        
        return 305
    }
        
    override var maxHeight: CGFloat {
        
        return UIScreen.main.bounds.size.height - 88
    }
    
    override var dimmingColor: UIColor {
        return .clear
    }
    
    open override var animateWhenFirstAppear: Bool {
        
        return false
    }
    
    override func createContentView(_ boxView: UIView) -> UIView {
        
        return thirdVc.view
    }
    
    override var verticalScrollViews: [UIScrollView]?{
        return [thirdVc.tableView]
    }
    
    override var topHeadDragHeight: CGFloat?{
        return 56
    }
    
    //这里单独处理头部无法下拉问题
    override func bounceBackToNearestLocation(_ velocityY: CGFloat) {
        //这里56为自定义头部的searchView的高度，当手势从最顶部下拉时
        if startPanY < topHeadDragHeight ?? 56 && (dragStatus == .top) {
            // 手势在顶部操作的代码
            isTopToPullDown = true
            // 确保 scrollView 在主线程上进行操作
            DispatchQueue.main.async {
                self.currentVerticalScrollView?.setContentOffset(.zero, animated: false)
            }
        } else {
            // 手势在中间或底部操作的代码
            isTopToPullDown = false
        }

        let offsetYDelta = self.boxTopConstraint.constant - initialOffsetY
        if offsetYDelta == 0 && dragStatus == .middle{
            isFirstMiddeleUp = true
        }else{
            isFirstMiddeleUp = false
        }
        super.bounceBackToNearestLocation(velocityY)
    }

}
