//
//  DraggableBoxView.swift
//  SXSPublisher
//
//  Created by laidongling on 2022/2/21.
//

import UIKit
import SnapKit

typealias DragBoxProgressBlock = (_ progress: CGFloat, _ boxTopCns: CGFloat) -> ()
typealias DragBoxPullProgressBlock = (_ progress: CGFloat, _ boxTopCns: CGFloat) -> ()

/// 可拖拽View，抽象类，需要子类化
open class DraggableBoxView: UIView {

    /// 容器顶部圆角，默认16
   open	var topCornerRadius: CGFloat{
		return 16
	}
    
    /// 最小高度，默认为nil
    open var minHeight: CGFloat? {
        get{ return nil }
    }
	
	/// 中间高度，默认为nil
	open var middleHeight: CGFloat? {
		get{ return nil }
	}
	
	/// 顶部非scrollView的可拖拽高度
	open var topHeadDragHeight: CGFloat? {
		get{ return nil }
	}
	
	///是否需要中间层级
	var isNeedMiddle: Bool {
		return middleHeight != nil
	}
    
    /// 最大高度, 默认屏幕高度
    open var maxHeight: CGFloat {
        return UIScreen.main.bounds.size.height
    }
		
    /// 是否可以dismiss掉
    var canDismiss: Bool {
        return minHeight == nil
    }
    
    /// 是否可以拖拽, 默认true
    open var canDrag: Bool {
        return true
    }
    
    /// 第一次出现是否要动画, 默认true
    open var animateWhenFirstAppear: Bool {
        return true
    }
    
    /// 垂直滚动的view, 有就传
    open var verticalScrollViews: [UIScrollView]? {
        return nil
    }
    /// 当前滚动的垂直view
	var currentVerticalScrollView: UIScrollView?
    
    /// 水平滚动的view
    open var horizontalScrollViews: [UIScrollView]? {
        return nil
    }
    
    /// 是否支持触动反馈
    open var supportTouchFeedBack: Bool {
        return true
    }
	///滑动过程中的progress回调
	var dragProgressChangeBlock: DragBoxProgressBlock?
    
    open var dimmingColor: UIColor {
        return .black.withAlphaComponent(0.3)
    }
	
	
	/// 拖拽层三状态，上，中，下 层
	enum DragStatus: String {
		case top, middle, bottom
	}
	
	var dragStatus = DragStatus.bottom
    
    private var didLayout = false

	let animateDuration: CGFloat = 0.1
    
    var isFingerDragging = false
    
    class FallThoughView: UIView{
        override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
            if self.backgroundColor == .clear {
                return nil
            }
            return super.hitTest(point, with: event)
        }
    }
    /// 底部蒙层
    lazy var dimmingView: FallThoughView = {
        let view = FallThoughView()
		view.addGestureRecognizer(UITapGestureRecognizer.init(target: self, action: #selector(clickDimmingView)))
        view.backgroundColor = dimmingColor
        view.alpha = 0
        return view
    }()
    
    /// 可拖拽容器
    lazy var boxView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.layer.maskedCorners = [CACornerMask.layerMinXMinYCorner, CACornerMask.layerMaxXMinYCorner]
        view.layer.cornerRadius = topCornerRadius
        return view
    }()
    
    /// 实际显示内容View
    lazy var contentView: UIView = {
        return createContentView(boxView)
    }()
    
	var boxTopConstraint: NSLayoutConstraint!
    fileprivate var boxHeightConstraint: NSLayoutConstraint!
    
    fileprivate var panGesture: UIPanGestureRecognizer?
    
    fileprivate var observers = [NSKeyValueObservation]()
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setUpView()
    }
    
    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        setUpView()
    }
    
    func setUpView() {
        
        addSubview(dimmingView)
        addSubview(boxView)
        boxView.addSubview(contentView)
        
        setUpConstraint()
        
        addGesture()
        
        configData()
    }
    
    public func configData() {
        
    }
    
    func addGesture() {
        
        if canDrag {
            
            let panGesture = UIPanGestureRecognizer.init(target: self, action: #selector(dragContentView(_:)))
            panGesture.delegate = self
            contentView.addGestureRecognizer(panGesture)
            self.panGesture = panGesture
        }
        
    }
    
    func setUpConstraint() {
        
        dimmingView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        boxView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
        }
        boxTopConstraint = boxView.topAnchor.constraint(equalTo: self.bottomAnchor, constant: 0)
        boxTopConstraint.isActive = true
        
        boxHeightConstraint = boxView.heightAnchor.constraint(equalToConstant: maxHeight)
        boxHeightConstraint.isActive = true
        
        contentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    open override func layoutSubviews() {
        super.layoutSubviews()
        if !didLayout {
            didLayout = true
            self.layoutIfNeeded()
            
            if animateWhenFirstAppear, supportTouchFeedBack {
                impactFeedback()
            }
            
            self.boxViewDidLayout()
            
            UIView.animate(withDuration: animateWhenFirstAppear ? animateDuration : 0) {
                //
				
                if let minHeight = self.minHeight {
					self.boxTopConstraint.constant = (self.isNeedMiddle ? -self.middleHeight! : -minHeight)
                    self.dimmingView.alpha = 0
                } else {
                    self.boxTopConstraint.constant = -self.maxHeight
                    self.dimmingView.alpha = 1
                }
                self.layoutIfNeeded()
                
            } completion: { finished in
                // view呈现后再添加observer
                self.addScrollViewKVO()
                
            }

        }
    }
    
    public func boxViewDidLayout() {
        
    }
    
    public func refreshVerticalScrollViews() {
        addScrollViewKVO()
    }
    
    private func impactFeedback() {
        let feedback = UIImpactFeedbackGenerator.init(style: .light)
        feedback.prepare()
        feedback.impactOccurred()
    }
    
    /// 子类需要覆盖这个方法
    open func createContentView(_ boxView: UIView) -> UIView {
        fatalError("DraggableBoxView子类需要实现createContentView方法")
    }
    
    @objc func clickDimmingView() {

        slideDown()
    }

    public func slideUp(_ animated: Bool = true) {
        
		if animated {
			UIView.animate(withDuration: animated ? animateDuration : 0) {
				//
				self.boxTopConstraint.constant = -self.maxHeight
				self.dimmingView.alpha = 1
				self.layoutIfNeeded()
			} completion: { finished in
				//
				self.dragStatus = DragStatus.top
			}
		} else {
			self.boxTopConstraint.constant = -self.maxHeight
			self.dimmingView.alpha = 1
			self.layoutIfNeeded()
			self.dragStatus = DragStatus.top
		}
        

    }
	
	public func slideMiddele(_ animated: Bool = true) {
		
		if let middleH = middleHeight, middleH > 0 {
			UIView.animate(withDuration: animated ? animateDuration : 0) {
				//
				self.boxTopConstraint.constant = -middleH
				self.dimmingView.alpha = 0.5
				self.layoutIfNeeded()
			} completion: { finished in
				//
				self.dragStatus = DragStatus.middle
			}
		}
	}
    
	public func slideDown(_ animated: Bool = true, _ isHiddenAll: Bool = false) {
        
        UIView.animate(withDuration: animated ? animateDuration : 0) {
            //
            self.boxTopConstraint.constant = (self.canDismiss || isHiddenAll) ? 0 : -self.minHeight!
            self.dimmingView.alpha = 0
            self.currentVerticalScrollView?.setContentOffset(.zero, animated: true)

            self.layoutIfNeeded()
        } completion: { finished in
            //
			self.horizontalScrollViews?.first?.setContentOffset(.zero, animated: true)
            if self.canDismiss {
                self.removeFromSuperview()
            }
			self.dragStatus = DragStatus.bottom
        }
    }
    
    public func toHidden(){
        UIView.animate(withDuration: animateDuration) {
            self.boxTopConstraint.constant = 0
            self.dimmingView.alpha = 0
            self.layoutIfNeeded()
        } completion: { finished in
            
        }
    }
    public func toShow(){
        UIView.animate(withDuration: animateDuration) {
            self.boxTopConstraint.constant = -self.minHeight!
            self.dimmingView.alpha = 0
            self.layoutIfNeeded()
        } completion: { finished in
            
        }
    }
    
	var initialOffsetY: CGFloat = 0
	var startPanY: CGFloat = 0  //pan滑动手势开始的点Y
	//记录是否从顶部往下拉，默认false
	var isTopToPullDown = false
	var isFirstMiddeleUp = false  //记录是否第一次进来，从中间模式往上拉，默认false
    
    @objc func dragContentView(_ gesture: UIPanGestureRecognizer) {
        
        let offsetY = gesture.translation(in: gesture.view).y
        let velocityY = gesture.velocity(in: gesture.view).y
		
		gesture.setTranslation(.zero, in: gesture.view)
        
        isFingerDragging = false
        
        switch gesture.state {
        case .began:
			let startPoint = gesture.location(in: contentView)
			startPanY = startPoint.y
			
            initialOffsetY = self.boxTopConstraint.constant
            isFingerDragging = true
        case .changed:
            isFingerDragging = true
			if let scrollView = self.currentVerticalScrollView, scrollView.contentOffset.y > 0, offsetY > 0, !(startPanY < (topHeadDragHeight ?? 56) && dragStatus == .top) {
                break
            }
            var absoluteOffset = abs(self.boxTopConstraint.constant + offsetY)
            absoluteOffset = min(max(absoluteOffset, minHeight ?? 0), maxHeight)
            self.boxTopConstraint.constant = -absoluteOffset
            let alpha = (absoluteOffset - (minHeight ?? 0)) / (maxHeight - (minHeight ?? 0))
			self.dragProgressChangeBlock?(alpha, self.boxTopConstraint.constant)
            self.dimmingView.alpha = alpha
			
        case .ended, .cancelled, .failed:
			bounceBackToNearestLocation(velocityY)
        case .possible:
            break
        @unknown default:
            break
        }
    }
    
	func bounceBackToNearestLocation(_ velocityY: CGFloat) {
		  
        if let scrollView = self.currentVerticalScrollView, scrollView.contentOffset.y > 0, velocityY > 0, isTopToPullDown == false {
			//这里velocityY为负数代表向上滑动，此时偶尔contentOffsetY会大于0，会导致滑动不顺滑，所以，这里velocityY改成>0,只处理下滑的情况！！！
            return
        }
        let initialPercentage: CGFloat = 0.1
        let initialVelocity: CGFloat = 300
        
        let offsetYDelta = self.boxTopConstraint.constant - initialOffsetY
		//最大顶部到中间的距离
		let upTomiddeleDistance = maxHeight - (middleHeight ?? 0)
		//中部到底部的距离
		let middleToBottomDistance = (middleHeight ?? 0) - (minHeight ?? 0)
		
//		print("--offsetYDelta=\(offsetYDelta)- upTomiddeleDistance=\(upTomiddeleDistance)---middleToBottomDistance=\(middleToBottomDistance)----")
		
        let isDragDown = offsetYDelta >= 0
		if isDragDown && !isFirstMiddeleUp {
			//如果往下拽
			//isTopToPullDown:处理从顶部往下滑动无速度的情况下，依然要下拽成功
			if velocityY > initialVelocity || offsetYDelta > maxHeight * initialPercentage ||  (isTopToPullDown == true){
				dealDragResult(isDragDown: true, dragSuccess: true, isOut: (offsetYDelta > upTomiddeleDistance) ? true : false)
            } else {
				dealDragResult(isDragDown: true, dragSuccess: false, isOut: false)
            }
        } else {
			//如果往上拽
            if -velocityY > initialVelocity || -offsetYDelta > maxHeight * initialPercentage {
				dealDragResult(isDragDown: false, dragSuccess: true, isOut: (-offsetYDelta > middleToBottomDistance) ? true : false)

            } else {
				dealDragResult(isDragDown: false, dragSuccess: false, isOut: false)
            }
        }
    }
	
//	处理拉拽结果(isDragDown：是否向下拉；dragSuccess：拽成功没；isOut：是否用力过猛，需要垮级，如从上直接到下，只适用于有中间层级的时候)
	func dealDragResult(isDragDown: Bool, dragSuccess: Bool, isOut: Bool){
		if isDragDown == true { //下拉
			if isNeedMiddle == true { //有中间层
				if dragStatus == .top {
					dragSuccess ? (isOut ? slideDown() : slideMiddele()) : slideUp()
				}else if dragStatus == .middle{
					dragSuccess ? slideDown() : slideMiddele()
                }else if dragStatus == .bottom{
                    //最开始，默认状态为.bottom
                    dragSuccess ? slideDown() : slideMiddele()
                }
			}else{ //没有中间层时
				dragSuccess ? slideDown() : slideUp()
			}
		}else{  //上拉
			if isNeedMiddle == true { //有中间层
				if dragStatus == .middle {
					dragSuccess ? slideUp() : slideMiddele()
				}else if dragStatus == .bottom{
					dragSuccess ? (isOut ? slideUp() : slideMiddele()) : slideDown()
				}
			}else{ //没有中间层时
				dragSuccess ? slideUp() : slideDown()
			}
		}
	}
}

/// Touch event
extension DraggableBoxView {
    
    open override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let hitView = super.hitTest(point, with: event)
        if hitView == self {
            return nil
        }
        return hitView
    }
}

extension DraggableBoxView: UIGestureRecognizerDelegate {
    //是否允许另外冲突手势共存，返回true允许，false不允许
    public func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
	//是否要等冲突手势失败后，才响应自己的手势，返回true，要等，返回false不等，直接处理自己手势逻辑
    public func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRequireFailureOf otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        if let contains = horizontalScrollViews?.compactMap({$0.panGestureRecognizer}).contains(otherGestureRecognizer), contains == true {
            return true
        }
        return false
    }
}

extension DraggableBoxView {
    
    func addScrollViewKVO() {
        
        for observer in observers {
            observer.invalidate()
        }
        observers.removeAll()
        
        let verticalScrollViews = verticalScrollViews ?? []
        
        for srollView in verticalScrollViews {
            
            let observer = srollView.observe(\UIScrollView.contentOffset, options: .new, changeHandler: { [weak self] scrollView, change in
                self?._scrollViewDidScroll(scrollView)
            })
            observers.append(observer)
        }
        
        currentVerticalScrollView = verticalScrollViews.first
        
    }

    private func canMove() -> Bool {
        
        // 因为UIView动画过程中,frame始终是设置之后的值，所以要获取动画过程中动态的frame，需要使用Presentation Layer.
        var boxViewOriginY = self.boxView.frame.origin.y
        if let presentLayer = self.boxView.layer.presentation() {
            boxViewOriginY = presentLayer.frame.origin.y
        }
        
        return floor(boxViewOriginY) > floor(self.frame.size.height - maxHeight)
    }
    
    func _scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        self.currentVerticalScrollView = scrollView
        
        let canMove = canMove()
        
        if (scrollView.contentOffset.y < 0 && isFingerDragging) || canMove {
			// 确保 scrollView 对象有效
			guard scrollView.superview != nil else {
				return
			}
			// 确保 scrollView 在主线程上进行操作
			DispatchQueue.main.async {
				scrollView.setContentOffset(.zero, animated: false)
			}
        }
    }
}
