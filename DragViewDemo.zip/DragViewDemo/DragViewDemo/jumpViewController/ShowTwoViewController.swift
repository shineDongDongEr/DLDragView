//
//  ShowTwoViewController.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class ShowTwoViewController: UIViewController {

    lazy var oneDragView: AKTwoDragView = {
        let dragView = AKTwoDragView()
        return dragView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "两层可滑动弹框"
        view.backgroundColor = .white
        view.addSubview(oneDragView)
        oneDragView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
   
    @IBAction func click(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
}
