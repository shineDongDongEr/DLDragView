//
//  ShowThirdTabViewController.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class ShowThirdTabViewController: UIViewController {
    
    lazy var thirdDragView: AKThirdDragView = {
        let drag = AKThirdDragView()
        return drag
    }()
    
    // MARK: - lifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .purple
        title = "三层内部可垂直滑动"
        setUI()
//        tableView.register(UINib(nibName: "AKDragTestCell", bundle: nil), forCellReuseIdentifier: cellId)
    }
    
    // MARK: - privatMethod
    func setUI(){
        view.addSubview(thirdDragView)
        thirdDragView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
//        thirdDragView.slideMiddele()
    }
}

//extension ShowThirdTabViewController{
//    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        26
//    }
//
//    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        if let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as? AKDragTestCell{
//            cell.text = "第\(indexPath.row)行"
//            cell.textColor = .purple
//            return cell
//        }
//        return UITableViewCell()
//    }
//}
