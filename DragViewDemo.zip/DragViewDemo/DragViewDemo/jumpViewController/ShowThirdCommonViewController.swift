//
//  ShowThirdCommonViewController.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class ShowThirdCommonViewController: UIViewController {

    lazy var oneDragView: AKThirdCommonView = {
        let dragView = AKThirdCommonView()
        return dragView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "三层可滑动弹框"
        view.backgroundColor = .white
        view.addSubview(oneDragView)
        oneDragView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
   
    @IBAction func btnClick(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func completeclick(_ sender: UIButton) {
        oneDragView.slideDown(true, true)
    }
    
    
    @IBAction func pullToMiddele(_ sender: Any) {
        oneDragView.slideMiddele()
    }
}
