//
//  ShowFourViewController.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class ShowFourViewController: UIViewController {

    lazy var oneDragView: AKFourDragView = {
        let dragView = AKFourDragView()
        return dragView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "弹框内部可左右，垂直滑动处理"
        view.backgroundColor = .white
        view.addSubview(oneDragView)
        oneDragView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        oneDragView.fourVc.makeSwipGesture(false)
    }
    
}
