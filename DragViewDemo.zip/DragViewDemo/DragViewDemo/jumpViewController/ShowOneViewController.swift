//
//  ShowOneViewController.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class ShowOneViewController: UIViewController {
    lazy var oneDragView: AKOneDragView = {
        let dragView = AKOneDragView()
        return dragView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "普通展示弹框"
        view.backgroundColor = .white
        view.addSubview(oneDragView)
        oneDragView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    @IBAction func btnClick(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func upClick(_ sender: Any) {
        oneDragView.slideUp()
    }
    
    @IBAction func downClick(_ sender: Any) {
        oneDragView.slideDown()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        oneDragView.slideDown()
    }
}
