//
//  HomeMainViewController.swift
//  DragViewDemo
//
//  Created by laidongling on 2023/9/7.
//

import UIKit

class HomeMainViewController: UIViewController {

    @IBOutlet weak var topTitle: UILabel!
    @IBOutlet weak var topBgView: UIView!
    var currentIndex = 0
    var nextIndex = 0
    @objc let pageController:UIPageViewController = UIPageViewController.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
    @objc let pageControl  =  JXPageControlJump(frame: CGRect(x: 0, y: 0, width: 40, height: 10))
    @objc lazy var  allViewControllers:[UIViewController] = {
        
        return [leftVc,middleVc,rightVc]
    }()
    
    var transitionInProgress:Bool = false

    
    let leftVc = FourLayersViewController(.left)
    let middleVc = FourLayersViewController(.middle)
    let rightVc = FourLayersViewController(.right)

    
    // MARK: - lifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setPageViewController()
        setPageControl()
    }
   
    
    func setPageViewController(){
        
        pageController.delegate = self
        pageController.dataSource = self
//        makeBounces(false)
        addChild(pageController)
        view.addSubview(pageController.view)
        pageController.view.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(topBgView.snp.bottom)
        }
        
        setCustomViewController([allViewControllers[2]], direction: .forward, animation: false)
        setCustomViewController([allViewControllers[0]], direction: .forward, animation: false)
        setCustomViewController([allViewControllers[1]], direction: .forward, animation: true)
        pageController.view.addSubview(pageControl)
    }
    
    //pager滚动到某个屏幕
    func setCustomViewController(_ vc :[UIViewController],direction: UIPageViewController.NavigationDirection,animation:Bool){
            pageController.setViewControllers(vc, direction: direction, animated: animation) { [weak self] finished in
                self?.transitionInProgress = false
            }
    }
    
    func setPageControl(){
        pageControl.isAnimation = false
        pageControl.numberOfPages = allViewControllers.count
        pageControl.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        pageControl.activeColor = .green
        pageControl.layer.cornerRadius = 5
        pageControl.inactiveSize = CGSize(width: 4, height: 4)
        pageControl.activeSize = CGSize(width: 8, height: 4)
        pageControl.columnSpacing = 4
        pageControl.contentAlignment = JXPageControlAlignment(.center,.center)
        pageControl.isInactiveHollow = false
        pageControl.isActiveHollow = false
        pageControl.currentPage = 1
        pageControl.snp.makeConstraints { make in
            make.centerX.equalTo(pageController.view)
            make.bottom.equalTo(pageController.view).offset(-39)
            make.height.equalTo(10)
            make.width.equalTo(40)
        }
    }
}
extension HomeMainViewController :UIPageViewControllerDelegate{
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return allViewControllers.count
    }
    func pageViewController(_ pageViewController: UIPageViewController, willTransitionTo pendingViewControllers: [UIViewController]) {
        //获取当前要被转换的VC，设置pageControl的当前页
        guard let vc = pendingViewControllers.first,let index = allViewControllers.firstIndex(of: vc) else{ return }
        
        nextIndex = index
    }
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if completed{
            currentIndex = nextIndex
            pageControl.updateProgress(CGFloat(currentIndex))
            
        }
        self.transitionInProgress = false
    }
}

extension HomeMainViewController :UIPageViewControllerDataSource{
    
    //获取前一个页面
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        //获取当前页面的索引
        guard let index = allViewControllers.firstIndex(of: viewController) else{return nil}
        //前一个页面
        let preIndex = index - 1
        //如果在第一页向右滑动则滚动到最后一页
        if preIndex < 0{
            return nil
        }
        //判断当前索引是否大于0且少于总索引个数
        guard  preIndex >= 0 , allViewControllers.count > preIndex else{return nil}
        return allViewControllers[preIndex]
    }
    //获取后一个页面
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        //获取当前页面的索引
        guard let index = allViewControllers.firstIndex(of: viewController) else{return nil}
        //前一个页面
        let nextIndex = index + 1
        //如果在最后页向左滑动则滚动到第一页
        if nextIndex == allViewControllers.count{
//            return allViewControllers.first
            return nil
        }
        //判断当前索引是否大于0且少于总索引个数
        if allViewControllers.count>nextIndex{
            return allViewControllers[nextIndex]
        }else{
            return nil
        }
    }
    
    //开启or禁用滑动手势
    func makeSwipGesture(_ isEnable: Bool){
        let views = self.pageController.view.subviews
        for view in views {
            if let subView = view as? UIScrollView {
                subView.isScrollEnabled = isEnable
            }
        }
    }
    
    //获取pager的所有scrollviews
    func getAllScrolls() -> [UIScrollView]{
        var temp: [UIScrollView] = []
        let views = self.pageController.view.subviews
        for view in views {
            if let subView = view as? UIScrollView {
                temp.append(subView)
            }
        }
        return temp
    }
}
